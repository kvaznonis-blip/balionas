from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from typing import Dict, List
import numpy as np
import requests
from math import cos, radians

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")

# Windy API raktai
WINDY_API_KEY = "5glBJfbu6hEwpHD7N6Gny6DKA88thbUt"  # pagrindinis
WINDY_FORECAST_KEY = "kK9WXggDpAhbSeSXbVYiM8F4yIDhblVJ"  # forecast API

class TrajectoryPoint(BaseModel):
    lat: float = Field(..., description="Latitude")
    lon: float = Field(..., description="Longitude")

class TrajectoryInput(BaseModel):
    start: Dict[str, float] = Field(..., description="Starting point {lat, lon}")
    ascent_ms: float = Field(..., description="Ascent rate (m/s)")
    descent_ms: float = Field(..., description="Descent rate (m/s)")
    seconds: int = Field(..., description="Duration (s)")
    levels: List[str] = Field(..., description="Pressure levels")

@app.get("/")
def root():
    return FileResponse("static/index.html")

@app.post("/trajectory")
async def calc_trajectory(data: TrajectoryInput):
    try:
        # Validuojam pradinius duomenis
        if 'lat' not in data.start or 'lon' not in data.start:
            return {"error": "start turi turėti lat ir lon"}
        
        start_lat = float(data.start['lat'])
        start_lon = float(data.start['lon'])
        
        # Rezultatų sąrašas
        trajectories = []
        
        # Skaičiuojam kiekvienam lygiui
        for level in data.levels:
            # Gaunam vėją iš Windy API
            params = {
                "key": WINDY_FORECAST_KEY,
                "lat": start_lat,
                "lon": start_lon,
                "model": "ecmwf",
                "parameters": ["wind"],
                "levels": [level.replace("Pa", "")]
            }
            
            try:
                r = requests.get("https://api.windy.com/api/forecast/v2.1/point", params=params)
                r.raise_for_status()
                wind_data = r.json()
                
                # Ištraukiam vėjo komponentes
                u = wind_data['wind']['u'][0]  # east-west
                v = wind_data['wind']['v'][0]  # north-south
            except Exception as e:
                print(f"Windy API error: {str(e)}")
                u, v = 0, 0
            
            # Skaičiuojam trajektoriją
            points = [[start_lat, start_lon]]
            current_lat, current_lon = start_lat, start_lon
            
            # Žemės apskritimo metrų per laipsnį (apytiksliai)
            m_per_deg_lat = 111320.0
            m_per_deg_lon = 111320.0 * cos(radians(current_lat))
            
            # Simuliuojam judėjimą
            alt = 0
            for t in range(data.seconds):
                # Keičiam aukštį
                if alt < 30000:  # max 30km
                    alt += data.ascent_ms
                else:
                    alt -= data.descent_ms
                
                # Judėjimas pagal vėją (m/s -> laipsniai)
                dlat = (v) / m_per_deg_lat
                dlon = (u) / m_per_deg_lon
                
                current_lat += dlat
                current_lon += dlon
                points.append([current_lat, current_lon])
            
            trajectories.append(points)
        
        # Skaičiuojam vidutinę trajektoriją
        if trajectories:
            mean_points = []
            for i in range(len(trajectories[0])):
                lats = [traj[i][0] for traj in trajectories]
                lons = [traj[i][1] for traj in trajectories]
                mean_points.append([
                    float(np.mean(lats)),
                    float(np.mean(lons))
                ])
            trajectories.append(mean_points)
        
        return {
            "trajectories": trajectories
        }
        
    except Exception as e:
        print(f"Trajectory error: {str(e)}")
        return {"error": str(e)}
