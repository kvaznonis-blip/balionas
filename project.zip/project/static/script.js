let map, windyVisible = false, windyFrame;
let clickMarkers = [], rows = 0;
let windGridMarkers = [];
let trajLayers = {}, trajVisible = {};
const trajColors = {T1:"red",T2:"green",T3:"blue",T1R:"red",T2R:"green",T3R:"blue"};
const WIND_LAYERS=["0-100","100-200","200-1000","1000-2000","2000-3000","3000-4000","4000-5000","5000-10000"];
let trajLogVisible = true;
function debounce(fn,ms=400){let t;return(...a)=>{clearTimeout(t);t=setTimeout(()=>fn(...a),ms);};}

// ==== MAP INIT ====
function initMap(){
  map=L.map('map',{zoomControl:false}).setView([55.3,23.9],7);
  L.control.zoom({position:'bottomright'}).addTo(map);
  map.createPane('windPane'); map.getPane('windPane').style.zIndex=900;
  map.createPane('trajPane'); map.getPane('trajPane').style.zIndex=850;
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap'}).addTo(map);
  map.on('click',onMapClick);

  // Vėjo sluoksniai
  const list=document.getElementById('layersList');
  WIND_LAYERS.forEach(l=>{
    const id=`chk-${l}`;
    const row=document.createElement('label');
    row.className="layer-row";
    row.innerHTML=`<input type="radio" name="windLayer" id="${id}" data-layer="${l}"> ${l} m`;
    list.appendChild(row);
    document.getElementById(id).addEventListener('change',updateWindGridDebounced);
  });

  document.getElementById("run").addEventListener("click",()=>calculateAllPoints("T1"));
  document.getElementById("runAll").addEventListener("click",()=>calculateAllPoints("ALL"));
  document.getElementById("reverse").addEventListener("click",()=>calculateAllPoints("REV"));
  document.getElementById("clear").addEventListener("click",clearAll);
  document.getElementById("toggleWindy").addEventListener("click",toggleWindy);
  document.getElementById("showWindMap").addEventListener("change",updateWindGridDebounced);
  map.on("moveend",updateWindGridDebounced);
  map.on("zoomend",updateWindGridDebounced);
  document.getElementById("logHeader").addEventListener("click",toggleLog);
}
const updateWindGridDebounced=debounce(updateWindGrid,600);

// ==== WIND FIELD ====
async function updateWindGrid(){
  const prev = [...windGridMarkers];
  const show=document.getElementById("showWindMap").checked;
  if(!show){ prev.forEach(m=>map.removeLayer(m)); windGridMarkers=[]; return; }

  const active=document.querySelector('input[name="windLayer"]:checked');
  if(!active) return;

  const b=map.getBounds();
  const payload={north:b.getNorth(),south:b.getSouth(),east:b.getEast(),west:b.getWest()};
  let data;
  try{
    const r=await fetch("/windgrid",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
    data=await r.json();
  }catch(e){console.warn("Wind fetch failed",e);return;}

  prev.forEach(m=>map.removeLayer(m)); windGridMarkers=[];
  (data.points||[]).forEach(p=>{
    const icon=L.divIcon({className:"wind-arrow",html:`<div class="arrow" style="color:black;transform:rotate(${p.dir_deg}deg)">➤</div>`,iconSize:[20,20],iconAnchor:[10,10]});
    const mk=L.marker([p.lat,p.lon],{icon,pane:"windPane"}).addTo(map);
    windGridMarkers.push(mk);
  });
}

// ==== TRAJECTORIES ====
async function calculateAllPoints(mode){
  const latVal = parseFloat(document.getElementById("lat").value);
  const lonVal = parseFloat(document.getElementById("lon").value);

  // ✅ Fix: teisingai paimamos koordinatės iš clickMarkers
  let pts = [];
  if (clickMarkers.length > 0) {
    pts = clickMarkers.map(p => ({
      lat: p.lat,
      lon: p.lng || p.lon
    }));
  } else {
    if (!isNaN(latVal) && !isNaN(lonVal)) {
      pts = [{ lat: latVal, lon: lonVal }];
    }
  }

  if (pts.length === 0) {
    addLog("[⚠️] Nėra galiojančių taškų – patikrink įvestis arba pažymėk ant žemėlapio");
    return;
  }

  for (const pt of pts) {
    if (mode === "ALL") {
      await calcType(pt, "T1");
      await calcType(pt, "T2");
      await calcType(pt, "T3");
    } else if (mode === "REV") {
      for (const t of ["T1R", "T2R", "T3R"]) await calcType(pt, t);
    } else {
      await calcType(pt, mode);
    }
  }
}

async function calcType(p, type) {
  if (!p || isNaN(p.lat) || isNaN(p.lon)) {
    addLog(`[${type}] klaida: neteisingos koordinatės`);
    console.warn("DEBUG klaida: neteisingas taškas ->", p);
    return;
  }

  console.log("DEBUG traj point:", p); // 👈 matysi realias koordinates

  const payload = {
    lat: p.lat,
    lon: p.lon,
    altitude: +document.getElementById("altitude").value,
    speed: +document.getElementById("speed").value
  };

  addLog(`[${type}] start (${p.lat.toFixed(3)}, ${p.lon.toFixed(3)})`);

  try {
    const r = await fetch(`/trajectory_${type.toLowerCase()}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (!r.ok) {
      addLog(`[${type}] klaida: ${r.status}`);
      console.error(`[${type}] server returned:`, r.status, await r.text());
      return;
    }

    const d = await r.json();
    const coords = d.trajectory.map(pt => [pt.lat, pt.lon]);
    const line = L.polyline(coords, {
      color: trajColors[type],
      pane: "trajPane",
      dashArray: type.endsWith("R") ? "4,6" : null
    }).addTo(map);

    const id = `${type}-${p.lat.toFixed(3)}-${p.lon.toFixed(3)}`;
    trajLayers[id] = line;
    addToTrajList(type, p, id);
    addLog(`[${type}] baigta (${coords.length} taškai, šaltinis: ${d.src || "?"})`);
  } catch (e) {
    addLog(`[${type}] klaida: ${e.message}`);
    console.error(`[${type}] klaida:`, e);
  }
}

// ==== TRAJEKTORIJŲ SĄRAŠAS ====
function addToTrajList(type,p,id){
  const c=document.getElementById("logTraj");
  if(document.getElementById(id)) return;
  const row=document.createElement("div");
  row.id=id;
  row.innerHTML=`<label><input type="checkbox" checked data-id="${id}"><span style="color:${trajColors[type]}">${type}</span> (${p.lat.toFixed(2)},${p.lon.toFixed(2)}) <button class="x-btn" data-id="${id}">X</button></label>`;
  c.appendChild(row);
  row.querySelector("input").addEventListener("change",e=>{
    const i=e.target.dataset.id;if(trajLayers[i]){if(e.target.checked) map.addLayer(trajLayers[i]); else map.removeLayer(trajLayers[i]);}
  });
  row.querySelector(".x-btn").addEventListener("click",e=>{
    const i=e.target.dataset.id;if(trajLayers[i]){map.removeLayer(trajLayers[i]);delete trajLayers[i];}
    e.target.closest("div").remove();addLog(`[${type}] ištrinta`);
  });
}

// ==== LOG PANEL ====
function addLog(msg){
  const c=document.getElementById("calcLog");
  const row=document.createElement("div");
  row.innerHTML=`<span>${new Date().toLocaleTimeString()} ${msg}</span> <button class="x-btn small">x</button>`;
  c.appendChild(row);
  row.querySelector("button").addEventListener("click",()=>row.remove());
  c.scrollTop=c.scrollHeight;
}
function toggleLog(){
  const s=document.getElementById("logSections");
  trajLogVisible=!trajLogVisible;
  s.style.display=trajLogVisible?"block":"none";
  logHeader.innerText=trajLogVisible?"⬆ Trajektorijos / Logas":"⬇ Trajektorijos / Logas";
}
function clearAll(){
  Object.values(trajLayers).forEach(l=>map.removeLayer(l));
  trajLayers={}; document.getElementById("logTraj").innerHTML="";
  addLog("Visos trajektorijos išvalytos");
}

// ==== MAP CLICK ====
function onMapClick(e){
  const {lat,lng}=e.latlng;
  if(document.getElementById("autoFill").checked){
    document.getElementById("lat").value=lat.toFixed(6);
    document.getElementById("lon").value=lng.toFixed(6);
  }
  rows++;
  const id=`row-${rows}`;
  const m=L.marker([lat,lng]).addTo(map).bindPopup(`#${rows}`);
  clickMarkers.push({id,marker:m,lat,lng});
  const tr=document.createElement("tr");
  tr.id=id;tr.innerHTML=`<td>${rows}</td><td>${lat.toFixed(6)}</td><td>${lng.toFixed(6)}</td><td><button class="x-btn" data-id="${id}">X</button></td>`;
  coordsTable.querySelector("tbody").appendChild(tr);
  tr.querySelector(".x-btn").addEventListener("click",ev=>{
    const rid=ev.target.dataset.id;const idx=clickMarkers.findIndex(p=>p.id===rid);
    if(idx>=0){map.removeLayer(clickMarkers[idx].marker);clickMarkers.splice(idx,1);}tr.remove();
  });
}

// ==== WINDY TOGGLE ====
function toggleWindy(){
  if(windyVisible){windyFrame.remove();windyVisible=false;}
  else{
    windyFrame=document.createElement("iframe");
    windyFrame.src="https://embed.windy.com/embed2.html?lat=55.3&lon=23.9&zoom=6&level=surface&overlay=wind";
    Object.assign(windyFrame.style,{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",border:"none",zIndex:400});
    document.body.appendChild(windyFrame);windyVisible=true;
  }
}

document.addEventListener("DOMContentLoaded",initMap);